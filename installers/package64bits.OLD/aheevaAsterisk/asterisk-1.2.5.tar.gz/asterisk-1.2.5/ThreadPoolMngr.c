#include "asterisk/lock.h"
#include "ThreadPoolMngr.h"
#include <signal.h>
#include <stdlib.h>

struct Thread
{
	ast_mutex_t lock;
	ast_cond_t  waitingForJob;
	int             working;
	void * (* func) (void *data);
	void *data;
	pthread_t self;
	struct Thread *prev;
	struct Thread *next;
};

static struct Thread *firstThread = NULL;
static ast_mutex_t allThreadsMutex;

/* Infile (private) available functions */
static void addThread( struct Thread *thread );
static struct Thread *getThread( void );
static void* worker(void *pwork);

/*-----------------------------------------------------------------------------*/
/*---------------------------------< worker >----------------------------------*/
/*-----------------------------------------------------------------------------*/
static void* worker(void *pwork)
{
	struct Thread *pThread = (struct Thread *) pwork;

	if( pThread == NULL )
	{
		return NULL;
	}

	signal( SIGPIPE, SIG_IGN );

	while( 1 )
	{
		ast_log( LOG_NOTICE, "Thread [%lu] ready for a job.\n", pThread->self );
		ast_mutex_lock(&pThread->lock);

		if(pThread->working == 0)		/* If we don't have a job scheduled, we wait */
			ast_cond_wait(&pThread->waitingForJob, &pThread->lock);

		ast_log( LOG_NOTICE, "Thread [%lu] about to execute a job\n", pThread->self );

		pThread->func( pThread->data );

		ast_log( LOG_NOTICE, "Thread [%lu] finished a job\n", pThread->self );
		pThread->working = 0;
		ast_mutex_unlock(&pThread->lock);
	}
}

/*-----------------------------------------------------------------------------*/
/*-------------------------------< tpmExecute >--------------------------------*/
/*-----------------------------------------------------------------------------*/
void tpmExecute( void * (* func) (void *data) , void *data )
{
	ast_mutex_lock( &allThreadsMutex );
	struct Thread *pThread;

	pThread = getThread();
	if( pThread == NULL )
	{
		ast_log( LOG_NOTICE, "Thread pool empty. Creating a new thread...\n" );
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		pthread_t threadId;
		pThread = (struct Thread *) malloc( sizeof(struct Thread) );
		ast_mutex_init( &(pThread->lock) );
		ast_cond_init( &(pThread->waitingForJob) , NULL );
		pThread->working = 0;
		ast_log( LOG_NOTICE, "Creating an extra thread [%lu]\n", threadId );
		pthread_create( &threadId , NULL , worker , (void *)pThread );
		pThread->self = threadId;
		addThread( pThread );
	}
	else
	{
		ast_log( LOG_NOTICE, "Got a thread from the pool [%lu]\n", pThread->self );
	}
	ast_mutex_lock(&pThread->lock);
	pThread->func = func;
	pThread->data = data;
	pThread->working = 1;
	ast_cond_signal( &pThread->waitingForJob );
	ast_mutex_unlock(&pThread->lock);
	ast_log( LOG_NOTICE, "Thread [%lu] signaled\n", pThread->self );

	ast_mutex_unlock(&allThreadsMutex);
}

/*-----------------------------------------------------------------------------*/
/*-----------------------------< tpmInitialize >-------------------------------*/
/*-----------------------------------------------------------------------------*/
void tpmInitialize( const int nb_threads )
{
	struct Thread *pThread;
	pthread_t threadId[nb_threads];
	int i = 0;

	ast_log( LOG_NOTICE, "Number of threads to create[%d]\n", nb_threads );

	ast_mutex_init( &allThreadsMutex );

	ast_mutex_lock( &allThreadsMutex );

	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	for( i = 0 ; i < nb_threads ; i++ )
	{
		pThread = (struct Thread *) malloc( sizeof(struct Thread) );
		ast_mutex_init( &(pThread->lock) );
		ast_cond_init( &(pThread->waitingForJob) , NULL );
		pThread->working = 0;
		pthread_create( &threadId[i] , NULL , worker , (void *)pThread );
		pThread->self = threadId[i];
		ast_log( LOG_NOTICE, "Create pool manager thread [%d] [%lu]\n", i, threadId[i] );
		addThread( pThread );
	}
	ast_mutex_unlock( &allThreadsMutex );
}

/*-----------------------------------------------------------------------------*/
/*--------------------------------< addThread >--------------------------------*/
/*-----------------------------------------------------------------------------*/
static void addThread( struct Thread *pThread )
{
	pThread->prev = NULL;
	pThread->next = firstThread;
	if( firstThread )
		firstThread->prev = pThread;
	firstThread = pThread;
}

/*-----------------------------------------------------------------------------*/
/*-------------------------------< getThread >---------------------------------*/
/*-----------------------------------------------------------------------------*/
static struct Thread *getThread( void )
{
	struct Thread *pThread = NULL;

	if( firstThread )
	{
		pThread = firstThread;

		while( pThread )
		{
			if( pThread->working == 0 )
			{
				break;
			}
			pThread = pThread->next;
		}
	}
	else
	{
		ast_log( LOG_NOTICE, "No thread available in the pool... not initialized. \n" );
	}
	return pThread;
}
