static int bit_next(int prev)
{
	return (prev + 1) % 256;
}
