/*
 * version.h 
 * Automatically generated
 */
#define ZAPTEL_VERSION "1.2.4"

