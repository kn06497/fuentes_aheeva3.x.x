#ifndef	CARDS_H
#define	CARDS_H

#include "xpd.h"

struct xpd_card_ops {
	int	(*card_new)(xpd_t *xpd);
	int	(*card_remove)(xpd_t *xpd);
#if 0
	int	(*zaptel_setup)(xpd_t *xpd);
	int	(*zaptel_cleanup)(xpd_t *xpd);
#endif
	int	(*card_startup)(struct zt_span *span);
	int	(*card_shutdown)(struct zt_span *span);
	int	(*card_spanconfig)(struct zt_span *span, struct zt_lineconfig *lc);
	int	(*card_chanconfig)(struct zt_chan *chan, int sigtype);
	int	(*card_sethook)(struct zt_chan *chan, int hookstate);
	int	(*card_ioctl)(struct zt_chan *chan, unsigned int cmd, unsigned long arg);
};

xops_t *get_xops(xpd_type_t xpd_type);

#endif	/* CARDS_H */
