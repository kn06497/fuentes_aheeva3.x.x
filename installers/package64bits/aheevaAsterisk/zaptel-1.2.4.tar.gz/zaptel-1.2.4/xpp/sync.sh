#!/bin/sh

set -e

SVN_ROOT=/home/tzafrir/Proj/Svn
XORTEL_DIR=$SVN_ROOT/xpp-zaptel/trunk/xortel
XPP_DIR=$SVN_ROOT/xpp-zaptel/trunk/zaptel/xpp
TARGET_DIR=xpp
FIRMWARE=$SVN_ROOT/fpgafirmware/init.dat

curdir=$PWD
cd $XORTEL_DIR
  cd ..; svn update; 
  cd xortel
  make FIRMWARE="$FIRMWARE" ../zaptel/xpp/slic_init.inc
cd $curdir

cp -a $XORTEL_DIR/FPGA_XPD.hex ${TARGET_DIR}/
cp -a $XORTEL_DIR/xpd.h ${TARGET_DIR}/
cp -a $XORTEL_DIR/xpp_zap.[ch] ${TARGET_DIR}/
cp -a $XORTEL_DIR/xproto.[ch] ${TARGET_DIR}/
cp -a $XORTEL_DIR/xdefs.h ${TARGET_DIR}/
cp -a $XORTEL_DIR/xpp_usb.c ${TARGET_DIR}/
cp -a $XORTEL_DIR/zap_debug.[ch] ${TARGET_DIR}/
cp -a $XORTEL_DIR/slic.[ch] ${TARGET_DIR}/
cp -a $XORTEL_DIR/card_*.[ch] ${TARGET_DIR}/
cp -a $XORTEL_DIR/xpp_fxloader{,.usermap} ${TARGET_DIR}/
cp -a $XORTEL_DIR/xpp_modprobe ${TARGET_DIR}/
cp -a $XORTEL_DIR/gen_slic_init ${TARGET_DIR}/
cp -a $XPP_DIR/Makefile ${TARGET_DIR}/
cp -a $XPP_DIR/slic_init.inc ${TARGET_DIR}/
