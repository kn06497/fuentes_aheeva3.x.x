[ -z "$JAVA_HOME" ] && 
JAVA_HOME="/usr/jdk1.5.0_06"
export JAVA_HOME
