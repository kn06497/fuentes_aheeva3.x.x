
//Default values of public fields:
allExceptFilter = new Array("A.*", "BUTTON.*", 
							"INPUT.*", "OBJECT.*", 
							"OPTION.*", "SELECT.*", 
							"TEXTAREA.*", "DIV.topmenu");

/*
noneExceptFilter = new Array();
menuClassName = "jsdomenudiv";
menuItemClassName = "jsdomenuitem";
menuItemClassNameOver = "jsdomenuitemover";
sepClassName = "jsdomenusep";
arrowClassName = "jsdomenuarrow";
arrowClassNameOver = "jsdomenuarrowover";
menuMode = "cursor";
menuBorderWidth = 2;
menuBarClassName = "jsdomenubardiv";
menuBarItemClassName = "jsdomenubaritem";
menuBarItemClassNameOver = "jsdomenubaritemover";
menuBarItemClassNameClick = "jsdomenubaritemclick";
menuBarDragClassName = "jsdomenubardragdiv";
menuBarMode = "absolute";
menuBarActivateMode = "click";
menuBarBorderWidth = 2;
*/

// Uncomment any of the following public properties to override the default value.
//var allExceptFilter = 
//var noneExceptFilter = 
//var menuClassName = 
//var menuItemClassName = 
//var menuItemClassNameOver = 
//var sepClassName = 
//var arrowClassName = 
//var arrowClassNameOver = 
//var menuMode = 
//var menuBorderWidth = 
//var menuBarClassName = 
//var menuBarItemClassName = 
//var menuBarItemClassNameOver = 
//var menuBarItemClassNameClick = 
//var menuBarDragClassName = 
//var menuBarMode = 
//var menuBarActivateMode = 
//var menuBarBorderWidth = 
