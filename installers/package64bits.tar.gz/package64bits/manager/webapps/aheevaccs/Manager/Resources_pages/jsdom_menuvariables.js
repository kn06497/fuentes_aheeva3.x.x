// JavaScript Document
//DEFINIT LES VARIABLES UTILISEES PAR LE MENU CONTEXTUEL
var ah_AgtMenuObj;
	var ah_MenuAgtName;	
	var ah_MenuSetAgtStatus;
	var ah_MenuSetAgtStatus_1;
		var ah_MenuSetAgtStatus_ready;
		var ah_MenuSetAgtStatus_notready;
		var ah_MenuSetAgtStatus_logout;
	var ah_MenuSetAgtPorperties;
	var ah_AgtFilter;
var ah_GrpMenuObj;
	var ah_MenuGrpName;
	var ah_MenuSetGrpStatus;
		var ah_MenuSetGrpStatus_ready;
		var ah_MenuSetGrpStatus_notready;
		var ah_MenuSetGrpStatus_logout;
	var ah_MenuSetGrpPorperties;
	var ah_GrpFilter;
var ah_QueMenuObj;
var ah_CamMenuObj;
	var ah_MenuCamName;
	var ah_MenuSetCamStatus;
		var ah_MenuSetCamStatus_ready;
		var ah_MenuSetCamStatus_notready;
		var ah_MenuSetCamStatus_logout;
	var ah_MenuSetCamPorperties;
	var ah_CamFilter;

var ah_CalMenuObj;
var ah_PerMenuObj;
var ah_TeaMenuObj;
var ah_menuwidth = 150;


