
function ProcessDonation(){
	if(reqSearch.readyState == 4) {
		if(reqSearch.status == 200) {
			document.getElementById("donation").innerHTML = reqSearch.responseText;
		}
	}
}

function donateHide(){
	InitializeSearch();
	var url="/donate.cgi";
	if(reqSearch!=null){
		reqSearch.onreadystatechange = ProcessDonation;
		reqSearch.open("GET", url, true);
		reqSearch.send(null);
	}
}